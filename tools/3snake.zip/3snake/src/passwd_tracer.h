#ifndef SNAKE_PASSWD_TRACER
#define SNAKE_PASSWD_TRACER

void intercept_passwd(pid_t traced_process);

#endif
