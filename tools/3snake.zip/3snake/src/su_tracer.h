#ifndef SNAKE_SU_TRACER
#define SNAKE_SU_TRACER

void intercept_su(pid_t traced_process);

#endif
