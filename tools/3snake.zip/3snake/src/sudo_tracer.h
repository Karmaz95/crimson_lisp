#ifndef SNAKE_SUDO_TRACER
#define SNAKE_SUDO_TRACER

void intercept_sudo(pid_t traced_process);

#endif
