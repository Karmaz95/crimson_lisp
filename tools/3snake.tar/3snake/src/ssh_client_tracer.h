#ifndef SNAKE_SSH_CLIENT_TRACER
#define SNAKE_SSH_CLIENT_TRACER

void intercept_ssh_client(pid_t traced_process);

#endif
